library("streetnamer")
library("tidywikidatar")
library("latlon2map")

user_base <- tibble::tibble(
  user = c("down"),
  password = c("load"),
  permissions = c("download"),
  name = c("Download")
)
options(shiny.launch.browser = .rs.invokeShinyWindowExternal)
options(timeout = 60000) # big timeout, as big downloads needed 

ll_set_folder(path = fs::path(fs::path_home_r(),
                              "R",
                              "ll_data"))

library(dplyr, warn.conflicts = FALSE)
library("tidywikidatar")

tw_set_language(language = "en")

connection <- tw_set_cache_db(driver = "MySQL",
                              database = "tidywikidatar",
                              user = "secret_username",
                              pwd = "secret_password")


sn_run_app(country_name = "Romania",
           connection = connection)

### 
ll_osm_get_lau_streets(
  gisco_id = current_gisco_id,
  country = current_country_name,
  unnamed_streets = FALSE
)

current_country_v <- stringr::str_extract(
  string = input$current_gisco_id,
  pattern = "[A-Z][A-Z]"
)

not_checked_df <- current_streets_sf_r() %>%
  sf::st_drop_geometry() %>%
  dplyr::distinct(name) %>%
  dplyr::anti_join(
    y = sn_get_street_named_after_id(
      country = current_country_v,
      remove_ignored = FALSE,
      only_checked = TRUE,
      keep_only_latest = TRUE,
      connection = golem::get_golem_options("connection")
    ) %>%
      dplyr::distinct(street_name) %>%
      dplyr::rename(name = street_name),
    by = "name"
  )
