library(testthat)
library(streetnamer)

test_check("streetnamer")
